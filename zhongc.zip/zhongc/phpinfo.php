<?php
 phpinfo(); 
?>