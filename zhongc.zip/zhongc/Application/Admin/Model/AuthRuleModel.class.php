<?php

namespace Admin\Model;
use Think\Model;
/**
 * 权限规则模型
 * @author  
 */
class AuthRuleModel extends Model{
    
    const RULE_URL = 1;
    const RULE_MAIN = 2;

}
