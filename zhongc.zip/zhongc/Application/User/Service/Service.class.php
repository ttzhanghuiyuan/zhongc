<?php

abstract class Service{


}
