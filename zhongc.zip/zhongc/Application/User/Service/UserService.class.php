<?php

class UserService extends Service{

}